# file3

source: `{{ page.path }}`
