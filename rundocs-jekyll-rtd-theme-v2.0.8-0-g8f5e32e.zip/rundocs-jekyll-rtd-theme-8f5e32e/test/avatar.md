---
sort: 7
---

# Avatar Test

```
{% raw %}{% avatar saowang %}{% endraw %}
```

{% avatar saowang %}

```tip
Set config `plugins: [jekyll-avatar]`

For documentation, see: [https://github.com/benbalter/jekyll-avatar](https://github.com/benbalter/jekyll-avatar)
```
