---
sort: 10
---

# Font Awesome Test - beta

```html
<i class="fa fa-check-circle text-green">checked</i>
<i class="fa fa-battery-quarter text-red">battery</i>
```

<i class="fa fa-check-circle text-green">checked</i>
<i class="fa fa-battery-quarter text-red">battery</i>

```note
MAYBE `material-design-icons` IS BETTER!
```
